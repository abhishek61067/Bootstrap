<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="2500">
    <div class="carousel-inner" role="listbox">
      <div class="carousel-caption">
         <div class="caption"> 
         <small>We Specialize In All </small>
         <h1>Mobile Car and <br><span>Truck Detailing</span></h1>
         <p>Onyx Ceramic Coatings</p> 
         </div>
         <!--<div class="testimonial-top">-->
         <!-- <div class="tp">-->
         <!--  <div class="total">50 REVIEWS</div>   -->
         <!--  <div class="point">4.0/5</div>-->
         <!--  </div>-->
         <!--  <div class="name">Patricia Glenane</div>-->
         <!--  <div class="rating">-->
         <!--    <i class="fa fa-star" aria-hidden="true"></i>-->
         <!--    <i class="fa fa-star" aria-hidden="true"></i>-->
         <!--    <i class="fa fa-star" aria-hidden="true"></i>-->
         <!--    <i class="fa fa-star" aria-hidden="true"></i>-->
         <!--    <i class="fa fa-star-o" aria-hidden="true"></i>-->
         <!--  </div>-->
         <!--  <p>I highly recommend Andy. I booked my SUV in for a full detail.  He did a magnificent job and I took up his offer of ceramic coating at a discounted rate.  My car looks and smells brand new.  The before and after photos don’t do it justice.</p>-->
         <!--  <a style="color: #fff;" href="testimonials.php">View more...</a>-->
         <!--</div>        -->
       </div>
      <div class="item active">
        <img src="images/slider/slider01.jpg" alt="Banner">       
     </div> 
     <div class="item">
        <img src="images/slider/slider02.jpg" alt="Banner">        
     </div> 
   </div>
 </div>

 <div class="top">
  <div class="">  
    <div class="col-md-6 padd0">
      <small>THE BEST</small>
      <h2><span>CAR DETAILING IN MELBOURNE</span> <br>AT AN AFFORDABLE PRICE</h2>
      <br>
      <p>Overspray Solutions was created by a group of Melbourne car enthusiasts who have a passion for cars and car presentation. We are obsessed with creating a perfect finish and keeping cars clean and well protected. Using only high-quality car cleaning products and detailing supplies, you can be assured that our car wash services are safe for your car.</p>
      <p>While we might not be the cheapest car detailing you could find in Australia, we are confident that our prices provide you with superior value. Our car detailing is second to none and we are constantly improving our processes to ensure we provide our customers with an impressive end result. We are also introducing top-quality car care and cleaning products for you to use at home.</p>
      <a href="about.php">Read More</a>
    </div>
    <div class="col-md-6 del-mbl">
      <img src="images/01.jpg" class="img-responsive">
    </div>
  </div>
  <div class="">   
    <div class="col-md-6">
      <img src="images/02.jpg" class="img-responsive">
    </div> 
    <div class="col-md-6 padd0">
      <h2>DETAILING</h2>
      <div class="row">
        <div class="col-xs-6">
          <h3><b>01.</b> Paint Correction</h3>  
          <p>Overspray Solution uses different phases of abrasive polishes along with our modern day polishing method sand equipment to achieve the best finish possible for the services we offer.</p>
        </div>
        <div class="col-xs-6">
          <h3><b>02.</b> Paint Protection</h3>  
          <p>Get the best paint protection services from Overspray Solution and maintain your new vehicle’s appearance and resale value. We offer our services for all makes, models, and sizes of vehicles. </p>
        </div>
        <div class="col-xs-6">
          <h3><b>03.</b> Graphene Coating</h3>  
          <p><b>10H Hardness</b> <br>

<b>Ultra Hard 10H Ceramic Coating</b> <br>

The advanced Nano-technology mixed with the properties of Graphene makes this coating the perfect, superior product in the Car Care industry that´s like no other.
</p>
        </div>
        <div class="col-xs-6">
          <h3><b>04.</b> Car Detailing</h3>  
          <p>From regular car washing to full detailing, Overspray Solution will keep your car looking it's absolute best. We will remove external & internal dust & debris and you will have your car sparkling. </p>
        </div>
      </div>

      <a href="services.php" style="margin-top:0">View More</a>
    </div>
  </div>
</div>


<!-- <div class="bottom">
  

  <img src="images/03.jpg" width="100%" class="img-responsive" alt="image">
</div>
 -->




<div class="video">
  <div class="">
    <div class="bg-car">
      <div class="vid-img">
        <img src="images/03.jpg" alt="car" class="img-fluid img-responsive">         
        <a data-toggle="modal" data-target=".bd-example-modal-lg">
          <span class="play-video"><i class="fa fa-play"></i></span>
        </a>
      </div>
    </div>
  </div>
</div>
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>        
      </div>
      <div class="modal-body">
        <video width="100%" controls>
  <source src="images/video.mp4" type="video/mp4">
</video>
    </div>
  </div>
</div>
</div>


<?php include('includes/footerpart.php') ?>

</body>
</html>