<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | Truck Detailing</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>Truck Detailing</h1>
  </div>

  <div class="sub-content services-page">
   <div class="container">
    <div class="row">
      <div class="col-md-5">
        <img src="images/services/07.jpg" alt="truck detailing" class="img-responsive">
      </div>
      <div class="col-md-7">
       <h2>Truck Detailing</h2>
       <!-- <p>Mobile Detailing Solutions specialise in all Truck detailing. <br><br>
We specialise in Pre delivery for truck dealerships.<br><br>
We do Aluminium polishing of tanks, Rims, Bullbars.<br><br>
We do for machine cut and polishing.<br><br>
We do Full interior cab and sleeper.<br><br>
Have a chat with one of our Mobile detailers and we can give you a estimate over the phone.<br><br>
We are fully mobile so we can come to you.<br><br>
We also do Ceramic Coatings for truck bodies.</p> -->



<p class="lead">MELBOURNE’S EXPERTS IN MOBILE TRUCK DETAILING</p>

<p>Speak to us and we can customise
a detailing package to suit your truck.
Restore that dull chalky oxidised, finish back to a smooth mirror finish. 
Remember the mirror finish on all your aluminium and paint work well we can restore it back to that original finish and add extra protection to pro long that finish. You will deal with the owner operator of this business so you get a full insight of what gets done and a firm quote. 
So Rims, Tanks, Bull bars, Paint, Chrome we can do it all.</p>

<h3 style="font-size: 18px;">EXCLUSIVE INTERIOR CARE</h3>

<p>You spend most of your working day inside the can of your truck so keeping in nice is important. As we all know in the truck industry they accumulate a lot of dirt. We love restoring the interiors of trucks and bring them back to a new like finish. We have all the gear on board our mobile vans to achieve that result.</p>

<h3 style="font-size: 18px;">CUT AND POLISH</h3>

<p>We bring your paint job back to peak condition, reversing the effects of the sun, pollution and wear-and-tear. We don’t stop until any scratches, dullness or other defects have been cleaned away. Truck can also pick up a lot of industrial full-out so we also remove Overspray and pollution from the paint.</p>  

     </div>

   </div>
 </div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>