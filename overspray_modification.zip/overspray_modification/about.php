<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | About Us</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>About Us</h1>
  </div>

  <div class="sub-content contact">
   <div class="container">
    <div class="row">
      <div class="col-md-5">
        <img src="images/about.jpg" alt="about" class="img-responsive">
      </div>
      <div class="col-md-7">
       <h2>About Us</h2>
       <p class="lead">Overspray Solutions was created by a group of Melbourne car enthusiasts who have a passion for cars and car presentation. We are obsessed with creating a perfect finish and keeping cars clean and well protected. Using only high-quality car cleaning products and detailing supplies, you can be assured that our car wash services are safe for your car.</p>

<p class="lead">While we might not be the cheapest car detailing you could find in Australia, we are confident that our prices provide you with superior value. Our car detailing is second to none and we are constantly improving our processes to ensure we provide our customers with an impressive end result. We are also introducing top-quality car care and cleaning products for you to use at home.</p>
     </div>

   </div>
 </div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>