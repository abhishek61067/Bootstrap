<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | QUARTZ 9H PRO</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>Ceramic Coating</h1>
  </div>

  <div class="sub-content services-page">
   <div class="container">
    <div class="row">
      <div class="col-md-5">
        <div class="row">
          <div class="col-md-12 col-xs-6">
            <img src="images/services/08.jpg" alt="about" class="img-responsive">
          </div>
          <div class="col-md-12 col-xs-6">
            <img src="images/services/09.jpg" alt="about" class="img-responsive">
          </div>
        </div>
      </div>
      <div class="col-md-7">


    <h2>Ceramic Coating</h2>  
        <h4>Graphene PRO 10H & N1</h4>
      
      <p class="lead">Ultra Hard 10H Ceramic Coating</p>
       <p>The advanced Nano-technology mixed with the properties of Graphene makes this coating the perfect, superior product in the Car Care industry that´s like no other.</p>

<p>Graphene Pro provides the ultimate shield for painted surfaces, metal surfaces, metal, and glass against damage with its 100% guaranteed chemical, scratch, and pollutant resistance that lasts a lifetime. This Ceramic Coating provides a thick layer of protection up to 1000nm.</p>

<p> Achieve a super smooth, extremely glossy, and hydrophobic invisible layer of protection through a simple application process.
</p>

<ul>
<li>World’s First N1 Nano Coating</li>
<li>10H Hardness</li>
<li>Stays Lifetime</li>
</ul>


       <h4>QUARTZ 9H PRO</h4>
        
<p>It is the professionally designed, expert solution to acquiring an immensely smooth and remarkably glossy, and hydrophobic surface that lasts up to 5 years and has a grade 3 chemical resistance.</p>

<p>The highly durable protection provides an invisible barrier that shields the exterior from chemicals, UV rays, water, oil, scratches, and oxidation. The Quartz 9H Pro contains Nano-technology that combines itself to the exterior making the protection almost inseparable from the surface. Its unique formula allows multiple layer application to increase the thickness and protection. This protection provides a thick layer up to 800nm.</p>

  <ul>
<li>Real Nano Coating</li>
<li>9H Hardness</li>
<li>5 Years</li>
  </ul>



     </div>


   </div>
 </div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>