<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | Projects</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <link href='dist/simplelightbox.min.css' rel='stylesheet' type='text/css'>
</head>
<body>
  <?php include('includes/headerpart.php') ?>

<div class="sub-banner">
    <h1>Our Projects</h1>
</div>

<div class="gallery-sec sub-content">
  <div class="container">
    <div class="gall-sec">
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/01.jpg" alt="" class="img-responsive">
                <a href="images/gallery/01.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/02.jpg" alt="" class="img-responsive">
                <a href="images/gallery/02.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/03.jpg" alt="" class="img-responsive">
                <a href="images/gallery/03.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/04.jpg" alt="" class="img-responsive">
                <a href="images/gallery/04.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/05.jpg" alt="" class="img-responsive">
                <a href="images/gallery/05.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/06.jpg" alt="" class="img-responsive">
                <a href="images/gallery/06.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/07.jpg" alt="" class="img-responsive">
                <a href="images/gallery/07.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/08.jpg" alt="" class="img-responsive">
                <a href="images/gallery/08.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/09.jpg" alt="" class="img-responsive">
                <a href="images/gallery/09.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/10.jpg" alt="" class="img-responsive">
                <a href="images/gallery/10.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/11.jpg" alt="" class="img-responsive">
                <a href="images/gallery/11.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/12.jpg" alt="" class="img-responsive">
                <a href="images/gallery/12.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/13.jpg" alt="" class="img-responsive">
                <a href="images/gallery/13.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/14.jpg" alt="" class="img-responsive">
                <a href="images/gallery/14.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/15.jpg" alt="" class="img-responsive">
                <a href="images/gallery/15.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/16.jpg" alt="" class="img-responsive">
                <a href="images/gallery/16.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/17.jpg" alt="" class="img-responsive">
                <a href="images/gallery/17.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/18.jpg" alt="" class="img-responsive">
                <a href="images/gallery/18.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/19.jpg" alt="" class="img-responsive">
                <a href="images/gallery/19.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/20.jpg" alt="" class="img-responsive">
                <a href="images/gallery/20.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/21.jpg" alt="" class="img-responsive">
                <a href="images/gallery/21.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/22.jpg" alt="" class="img-responsive">
                <a href="images/gallery/22.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/23.jpg" alt="" class="img-responsive">
                <a href="images/gallery/23.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/24.jpg" alt="" class="img-responsive">
                <a href="images/gallery/24.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/25.jpg" alt="" class="img-responsive">
                <a href="images/gallery/25.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/26.jpg" alt="" class="img-responsive">
                <a href="images/gallery/26.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
     <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/27.jpg" alt="" class="img-responsive">
                <a href="images/gallery/27.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
     
     
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/28.jpg" alt="" class="img-responsive">
                <a href="images/gallery/28.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/29.jpg" alt="" class="img-responsive">
                <a href="images/gallery/29.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/30.jpg" alt="" class="img-responsive">
                <a href="images/gallery/30.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/31.jpg" alt="" class="img-responsive">
                <a href="images/gallery/31.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        <div class="col-md-3 col-sm-6 col-xs-6">
          <div class="gallery-main text-center ">
            <div class="gallery">
              <div class="gallery-image">
                <img src="images/gallery/32.jpg" alt="" class="img-responsive">
                <a href="images/gallery/32.jpg" title="" data-lightbox-gallery="gallery1" class="nivo">
                  <div class="cap-option">
                    <i class="fa fa-search-plus"></i>
                  </div> 
                </a>
              </div>                 
            </div>
          </div>
        </div>
        
        
        
        
        
        
        
        
        
        

      </div>


    </div>

  </div>
</div>



    <?php include('includes/footerpart.php') ?>
    
    
    <script src="dist/simple-lightbox.js"></script>
    <script>
      $(function(){
        var $gallery = $('.gallery a').simpleLightbox();

        $gallery.on('show.simplelightbox', function(){
          console.log('Requested for showing');
      })
        .on('shown.simplelightbox', function(){
          console.log('Shown');
      })
        .on('close.simplelightbox', function(){
          console.log('Requested for closing');
      })
        .on('closed.simplelightbox', function(){
          console.log('Closed');
      })
        .on('change.simplelightbox', function(){
          console.log('Requested for change');
      })
        .on('next.simplelightbox', function(){
          console.log('Requested for next');
      })
        .on('prev.simplelightbox', function(){
          console.log('Requested for prev');
      })
        .on('nextImageLoaded.simplelightbox', function(){
          console.log('Next image loaded');
      })
        .on('prevImageLoaded.simplelightbox', function(){
          console.log('Prev image loaded');
      })
        .on('changed.simplelightbox', function(){
          console.log('Image changed');
      })
        .on('nextDone.simplelightbox', function(){
          console.log('Image changed to next');
      })
        .on('prevDone.simplelightbox', function(){
          console.log('Image changed to prev');
      })
        .on('error.simplelightbox', function(e){
          console.log('No image found, go to the next/prev');
          console.log(e);
      });
    });
</script>

  </body>
  </html>