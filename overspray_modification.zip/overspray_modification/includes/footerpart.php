<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6 col-xs-6">
        <h4><small>Contact</small><br> Contact Information</h4>
        <div class="info-blk clearfix">
          <img src="images/mobile-icon2.png" alt="">
          <h5>Phone Number:<br> <strong><a href="tel:0410939700">0410 939 700</a></strong></h5>
        </div>
        <div class="info-blk clearfix">
          <img src="images/email-icon.png" alt="">
          <h5>E-mail Address:<br> <strong><a href="mailto:info@cardetailingsolutions.com.au ">info@cardetailingsolutions.com.au </a></strong></h5>
        </div>
        <div class="info-blk clearfix">
          <img src="images/map-icon2.png" alt="">
          <h5>Visit Us:<br> <strong>Australia</strong></h5>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6">
        <h4><small>Service</small><br> Our services</h4>
        <div class="cato clearfix">
          <ul>
            <li><a href="full-deluxe-detail.php">Full Deluxe Detail</a></li>
            <li><a href="full-detail.php">Full Detail</a></li>
            <li><a href="interior-detailing.php">Interior Detailing</a></li>
            <li><a href="exterior-detailing.php">Exterior Detailing</a></li>
            <li><a href="ceramic-coating.php">Ceramic Coating</a></li>
            <li><a href="paint-correction.php">Paint Correction</a></li>            
            <li><a href="truck-detailing.php">Truck Detailing</a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 col-xs-6">
        <h4><small>Links</small><br> Quick links</h4>
        <div class="quick-link">
          <div class="cato clearfix">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="testimonials.php">Testimonials</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="projects.php">Our Projects</a></li>
              <li><a href="services.php">Services</a></li>
              <li><a href="contact.php">Contact us</a></li>
            </ul>
          </div>
        </div>

        <div class="opening">
          <p><img src="images/clock.png" alt=""> Opening Hours<br> 
            <strong>7am- 7pm 7days</strong></p>

          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-6">
          <h4><small>Social</small><br> Social Contact</h4>
          <div class="footer-social">
            <h5><a href="https://www.facebook.com/overspraysolutions/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i> Facebook</a></h5> 
            <h5><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i> Twitter</a></h5>
            <h5><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i> Google Plus</a></h5>
            <h5><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i> Linkedin</a></h5>
          </div>
        </div>
      </div>
      <hr>
      <div class="bottom-arrow">
       <a href="#top"><img src="images/bottom-arrow.png" alt=""></a>
     </div>
<style>
    .caltoactionfxeds p{
        line-height:20px;
    }
 .caltoactionfxeds{height: 4rem;
width: 3rem;
background: #EB3648;
position: fixed;
bottom: 16px;
left: 6rem;
border-radius: 50%;
left: 6rem;
border-radius: 0px;
padding: 10px;
  padding-left: 10px;
padding-left: 10px;
width: 15rem;
border-radius: 20px;
z-index: 1;
background: black;
color: white;
padding-left: 3rem;
z-index: 1111;
 }
 .caltoactionfxed{
height: 6.3rem;
width: 6.5rem;
background: green;
position: fixed;
bottom: 4px;
left: 13px;
border-radius: 50%;
z-index: 999999;
color: white;
 }
 .caltoactionfxeds a{
    display: flex;
justify-content: center;
align-content: center;
font-size: 3.2rem;
color: #007bff !important;
align-items: center;
padding-top: 11px;
width: 4rem;
padding: 10px;
 }
 .caltoactionfxed a{
       display: flex;
justify-content: center;
align-content: center;
font-size: 3.2rem;
color: green !important;
align-items: center;
padding-top: 7px; 
 }
 .iuiu{
    margin-bottom: 2rem;
 }
 .caltoactionfxeds .fa{
  font-size:1.6rem; color: white;
 }
 .caltoactionfxed .fa{
color: white;
font-size: 2.6rem;
top: 7px;
 }
 .caltoactionfxed .fa{  position: relative;
  animation: mymove 5s infinite;
 }
 @keyframes mymove {
  0% {transform: rotate(0deg);}
  20% {transform: rotate(20deg);}
  40% {transform: rotate(40deg);}
  60% {transform: rotate(60deg);}
  80% {transform: rotate(80deg);}
  100% {transform: rotate(100deg);}
}

</style>

<div class="caltoactionfxed">
    <div class="top">
        <a href="tel:0410 939 700">
          <i class="fa fa-phone" aria-hidden="true"></i></a>

    </div>
</div>

<div class="caltoactionfxeds">
    <div class="top">
              <p class="sss" style="color: white;font-size: 18px;">Call Now</p>
    </div>
</div>

     <div class="footer-bottom">
      <p>Copyright ©  Overspray Solution 2022 |  All rights reserved.</p>
      <p>Design by: <a href="http://www.pixeldesignau.com" target="_blank">Pixel Design</a></p>
    </div>
  </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script> 


<script type="text/javascript" src="dist/simple-lightbox.js"></script>
<script>
  $(function(){
    var $gallery = $('.gallery a').simpleLightbox();

    $gallery.on('show.simplelightbox', function(){
      console.log('Requested for showing');
    })
    .on('shown.simplelightbox', function(){
      console.log('Shown');
    })
    .on('close.simplelightbox', function(){
      console.log('Requested for closing');
    })
    .on('closed.simplelightbox', function(){
      console.log('Closed');
    })
    .on('change.simplelightbox', function(){
      console.log('Requested for change');
    })
    .on('next.simplelightbox', function(){
      console.log('Requested for next');
    })
    .on('prev.simplelightbox', function(){
      console.log('Requested for prev');
    })
    .on('nextImageLoaded.simplelightbox', function(){
      console.log('Next image loaded');
    })
    .on('prevImageLoaded.simplelightbox', function(){
      console.log('Prev image loaded');
    })
    .on('changed.simplelightbox', function(){
      console.log('Image changed');
    })
    .on('nextDone.simplelightbox', function(){
      console.log('Image changed to next');
    })
    .on('prevDone.simplelightbox', function(){
      console.log('Image changed to prev');
    })
    .on('error.simplelightbox', function(e){
      console.log('No image found, go to the next/prev');
      console.log(e);
    });
  });
</script>

