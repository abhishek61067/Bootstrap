<div class="head-absolute">
    <div class="container text-center">
      <div class="row">
        <div class="col-md-3 col-sm-3 col-xs-8 logo">
          <a href="index.php"><img src="images/logo.png" class="img-responsive logo-img" alt="Logo"></a>
        </div>  
        <div class="col-md-9 col-sm-9 col-xs-4">
          <div class="row">
          <div class="col-md-1 del1">
            <a class="n0v" href="index.php">Home</a>
          </div>
          <div class="col-md-3 del1">
            <a class="n0v" href="projects.php">Our Projects</a>
          </div>
          <div class="col-md-3 col-sm-5 del2">
            <a class="n0v call0" href="tel:0410939700"><i class="fa fa-phone" aria-hidden="true"></i> 0410 939 700</a>
          </div>
          <div class="col-md-4 col-sm-5 del2">
            <a href="contact.php" class="quote-btn">ENQUIRE NOW</a>
          </div>
          <div class="col-md-1 col-sm-2">
            <div id="myNav" class="overlay">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <div class="overlay-content">
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="services.php">Services</a>
            <a href="testimonials.php">Testimonials</a>
            <a href="projects.php">Our Projects</a>
            <a href="contact.php">Contact</a>
          </div>
        </div>

        <span class="navi-bar" onclick="openNav()">&#9776;</span>
          </div>         
        </div>
      </div>      
    </div>
  </div>
</div>






<script>
  function openNav() {
    document.getElementById("myNav").style.width = "100%";
  }

  function closeNav() {
    document.getElementById("myNav").style.width = "0%";
  }
</script>