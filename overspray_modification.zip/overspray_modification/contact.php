<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | Contact</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
      <h1>Contact Us</h1>
  </div>

  <div class="sub-content contact">
   <div class="container">
    <h2>Get in Touch</h2>
    <div class="row">
     <div class="col-md-7">
       <p class="lead">If you have some feedback please fill the form</p>


       <div class="form-box">
        <form action="response.php" class="contact__form" method="post">
          <div class="contact__msg"></div>
          <div class="row sm-cont">
           <div class="col-xs-6">
             <div id="c1"> 

              <label>Full Name*:</label>
              <input name="fullname" type="text" class="border"> 

              <label>Address:</label>
              <input name="address" type="text" class="border">   

              <label> Phone:</label>
              <input name="phone" type="number" class="border">

              <label> E-mail*:</label>
              <input name="email" type="email" class="border">    

            </div>
          </div>
          <div class="col-xs-6">
           <div id="c2">
            <label>Comments*:</label>
            <textarea name="comments" cols="20" rows="15" class="border" style="height:185px"></textarea>
<!-- 
            <div class="g-recaptcha" data-sitekey="6Lcs7wMgAAAAAIiHb1pU46lN5NW_jkxRc0j_GE5c"></div> -->

           <input name="Submit2" type="submit" value="SUBMIT" class="button" />

          </div>
        </div>
      </div>
    </form>
  </div>
</div>
<div class="col-md-5">
 <div class="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d17507807.403822273!2d124.30790749343456!3d-25.727598339977604!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2b2bfd076787c5df%3A0x538267a1955b1352!2sAustralia!5e0!3m2!1sen!2snp!4v1647925610590!5m2!1sen!2snp" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
</div>
</div>
</div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>