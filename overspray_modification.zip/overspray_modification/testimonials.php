<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | Contact</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>Testimonials</h1>
  </div>

  <div class="testimonials-page">
   <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="testimonial-box">        
           <p>I highly recommend Andy. I booked my SUV in for a full detail.  He did a magnificent job and I took up his offer of ceramic coating at a discounted rate.  My car looks and smells brand new.  The before and after photos don’t do it justice.</p>
           <div class="clients">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span><strong>Patricia Glenane</strong><br>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
            </span>
          </div>
         </div> 
      </div>

      <div class="col-md-6">
        <div class="testimonial-box">       
           <p>Andy is nothing but professional all throughout the process. The Onyx Graphene Pro ceramic coating that he put on my Toyota RAV4 is amazing. Could not recommend it enough. The service he provides is top notch; goes above and beyond. Overall very satisfied and wouldn't hesitate to recommend him to anyone.</p>
<div class="clients">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span><strong>Filo Guy</strong><br>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
            </span>
          </div>
         </div> 
      </div>   

       <div class="col-md-6">
        <div class="testimonial-box">       
           <p>Andy did a great job with my car (2018 Toyota Corolla Sedan). He cleaned it thoroughly, detailed it and applied a Ceramic Coating. Looks like new and really happy with the job! Highly recommend!!</p>
<div class="clients">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span><strong>Andrew Deane</strong><br>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
            </span>
          </div>
         </div> 
      </div>   

       <div class="col-md-6">
        <div class="testimonial-box">       
           <p>Andy was nothing less than fantastic!! He’s literally just left my home after doing a full car interior detail and mould remediation. He was professional and did the job required with extremely high standards. He even did some added extras free of charge which I’m so grateful for. I don’t often write reviews but use them to choose a service, but in this instance I thought leaving a positive review was definitely in order. I recommend Andy more than 100% Excellent job!! He went above and beyond and that’s extremely hard to find when hiring someone for any service. Thank You So Much</p>
<div class="clients">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span><strong>JORDAN PARKER</strong><br>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
              <i class="fa fa-star" aria-hidden="true"></i>
            </span>
          </div>
         </div> 
      </div>   

   </div>

 </div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>