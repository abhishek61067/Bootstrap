<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | QUARTZ 9H PRO</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>QUARTZ 9H PRO</h1>
  </div>

  <div class="sub-content services-page">
   <div class="container">
    <div class="row">
      <div class="col-md-5">
        <img src="images/services/09.jpg" alt="about" class="img-responsive">
      </div>
      <div class="col-md-7">
       <h2>QUARTZ 9H PRO</h2>
        
<p>It is the professionally designed, expert solution to acquiring an immensely smooth and remarkably glossy, and hydrophobic surface that lasts up to 5 years and has a grade 3 chemical resistance.</p>

<p>The highly durable protection provides an invisible barrier that shields the exterior from chemicals, UV rays, water, oil, scratches, and oxidation. The Quartz 9H Pro contains Nano-technology that combines itself to the exterior making the protection almost inseparable from the surface. Its unique formula allows multiple layer application to increase the thickness and protection. This protection provides a thick layer up to 800nm.</p>

  <ul>
<li>Real Nano Coating</li>
<li>9H Hardness</li>
<li>5 Years</li>
  </ul>



     </div>


   </div>
 </div>
</div>






<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>