<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Overspray Solution | Services</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/responsive.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
  <link href="favicon.ico" rel="shortcut icon">
  <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

  <?php include('includes/headerpart.php') ?>

  <div class="sub-banner">
    <h1>Our Services</h1>
  </div>

<div class="top">
  <div>    
    <div class="col-md-6 del-desk visb-mobl">
      <img src="images/services/01.jpg" class="img-responsive">
    </div>
    <div class="col-md-6 padd0">
   
      <h2>Full Deluxe Detail</h2>
      
<p>If you’re selling your car and you want to achieve the best possible sale price or you just want that brand new car feel back then we recommend a  Full deluxe detail. </p>
<ul>
<li>Paint work washed and decontaminated </li>
<li>Remove surface scratched </li>
<li>Step One Machine cut</li>
<li>Step two Machine glaze</li>
<li>Step three Machine polish and seal</li>
<li>Rims detailed inside and out</li>
<li>Tyres</li>
<li>Cleaned and dressed</li>
<li>Plastic moulds and trims dressed</li>
<li>Windows cleaned in and out</li>
<li>Engine bay pressure washed</li>
</ul>

     <a href="full-deluxe-detail.php">Read More</a>
    </div>
    <div class="col-md-6 del-mbl">
      <img src="images/services/01.jpg" class="img-responsive">
    </div>
  </div>
  <div>   
    <div class="col-md-6 visb-mobl">
      <img src="images/services/02.jpg" class="img-responsive">
    </div> 
    <div class="col-md-6 padd0">
      
      <h2 style="font-size:24px;">Full Detail</h2>
      
      <p>It’s important to keep your car in good condition to increase its longevity. Our expert detailers will take care of your car like it’s their own, so your car will be in safe hands. With all the inclusions of our Interior & Exterior details and much more, you will get your Car back as brand new. During a Full detail, our detailers carefully work through your car’s transformation, cleaning the interior trim, door jambs, and boot jambs for a full detail effect in a bit of the time.</p>

<b>Full Detail Service Includes:</b>
<ul>
<li>Exterior Wash By Hand</li>
<li>Chamois Dry</li>
<li>Door and Boot Jams Cleaned and Dressed</li>
<li>Boot Jams Cleaned and Dressed</li>
<!--<li>Windows and Mirrors Cleaned Inside and out</li>-->
<li>Dashboard and Trims Dusted</li>
<li>Interior Deodorised</li>
<li>Windows Cleaned</li>
<li>Wheels Cleaned/ Tyres Dressed</li>
<li>Interior Trims, and Console Detailed and Dressed</li>
<li>Machine Polish </li>
</ul>

      <a href="full-detail.php">Read More</a>
    </div>
    <div class="col-md-6 del-desk del-mbl">
      <img src="images/services/02.jpg" class="img-responsive">
    </div>
  </div>
  <div>    
    <div class="col-md-6 del-desk visb-mobl">
      <img src="images/services/03.jpg" class="img-responsive">
    </div>
    <div class="col-md-6 padd0">
      <h2>Interior Detailing</h2>
      
      <p>Here at Overspray Solution, we know that keeping your car in tip-top condition is the most needed for you. Our Interior Detailing service will confirm you will feel like you are driving a brand new car after we are finished. Detailing experts will use leading-edge equipment and processes to help remove stains and spills from your interior, clean off any dust and gunk and leave your car looking and smelling spotless.</p>
<b>Interior Detail Service Includes:</b>
<ul>
<li>Vacuum Seats, Carpet & Boot</li>
<li>Interior Trims Cleaned & Dressed</li>
<li>Shampoo Seats & Carpet Steam Cleaning</li>
<li>Interior Deodorised</li>
<li>Windows and Mirrors Cleaned Inside and Out</li>
<li>Sun Visors Cleaned</li>
</ul>

      <a href="interior-detailing.php">Read More</a>
    </div>
    <div class="col-md-6 del-mbl">
      <img src="images/services/03.jpg" class="img-responsive">
    </div>
  </div>
  <!-- <div>   
    <div class="col-md-6 visb-mobl">
      <img src="images/services/04.jpg" class="img-responsive">
    </div> 
    <div class="col-md-6 padd0">
     
      <h2>Window Tinting</h2>
      
      <p class="lead">Overspray Solution provides outstanding window tints that block harmful ultraviolet rays coming inside your car and keep your vehicle private and safe. We stock various ranges of tints with quality features. Our Car Window tinting will protect your car interior preventing sun damage reducing heat & glare and improving visual appeal. Stay private when driving and give your car a sleek look. 
</p>

      <a href="window-tinting.php">Read More</a>
    </div>

    <div class="col-md-6 del-desk del-mbl">
      <img src="images/services/04.jpg" class="img-responsive">
    </div>
  </div> -->

  <div>   
    <div class="col-md-6 visb-mobl">
      <img src="images/services/08.jpg" class="img-responsive" alt="Ceramic Coating">
    </div> 
    <div class="col-md-6 padd0">
     
      <h2>Ceramic Coating</h2>
      <h3>Graphene PRO 10H & N1</h3>
      <p class="lead">Ultra Hard 10H Ceramic Coating</p>
       <p>The advanced Nano-technology mixed with the properties of Graphene makes this coating the perfect, superior product in the Car Care industry that´s like no other.</p>

<p>Graphene Pro provides the ultimate shield for painted surfaces, metal surfaces, metal, and glass against damage with its 100% guaranteed chemical, scratch, and pollutant resistance that lasts a lifetime. This Ceramic Coating provides a thick layer of protection up to 1000nm.</p>

<p> Achieve a super smooth, extremely glossy, and hydrophobic invisible layer of protection through a simple application process.
</p>

<ul>
<li>World’s First N1 Nano Coating</li>
<li>10H Hardness</li>
<li>Stays Lifetime</li>
</ul>


      <a href="ceramic-coating.php">Read More</a>
    </div>

    <div class="col-md-6 del-desk del-mbl">
      <img src="images/services/04.jpg" class="img-responsive">
    </div>
  </div>


  <div>    

    <div class="col-md-6 del-desk visb-mobl">
      <img src="images/services/05.jpg" class="img-responsive">
    </div>
    <div class="col-md-6 padd0">
      <h2>Exterior Detailing</h2>
      
      <p>From regular car washing to exterior detailing, Overspray Solution will keep your car looking it's absolute best. We will remove external dust & debris and you will have your car sparkling. Exterior Detailing services are perfect for those that want their car cleaned and maintained on a weekly or monthly basis.</p>

<b>Exterior Detailing Services Involves:</b>
<ul>
<li>A pre-rinse wash</li>
<li>Applying Ph snow foam </li>
<li>Handwashing with the two-bucket method</li>
<li>Cleaning the wheels</li>
<li>Drying the vehicle with a towel</li>
<li>Cleaning the glass from outside </li>
<li>Drying the door jambs of excess water</li>
<li>Applying shine to the arches and wheels</li>
<li>Spray wax is applied to the exterior as we dry the vehicle</li>
</ul>

      <a href="exterior-detailing.php">Read More</a>
    </div>
    <div class="col-md-6 del-mbl">
      <img src="images/services/05.jpg" class="img-responsive">
    </div>
  </div>
  <div>   
    <div class="col-md-6 visb-mobl">
      <img src="images/services/06.jpg" class="img-responsive">
    </div> 
    <div class="col-md-6 padd0">
      <h2>Paint Correction</h2>
    <p>Over time due to washing and general wear and tear your vehicles paint will loose it’s natural gloss and protective coat. A build up of hair line scratches and oxidisation causes the paint to look dull and faded. The process we suggest is Paint correction. Give up a call and we can walk you through some packages we offer.</p>
      <a href="paint-correction.php">Read More</a>
    </div>

    <div class="col-md-6 del-desk del-mbl">
      <img src="images/services/06.jpg" class="img-responsive">
    </div>
  </div>



  <div>    

    <div class="col-md-6 del-desk visb-mobl">
      <img src="images/services/07.jpg" class="img-responsive">
    </div>
    <div class="col-md-6 padd0">
      <h2>Truck Detailing</h2>
       <p>Mobile Detailing Solutions specialise in all Truck detailing. <br>
We specialise in Pre delivery for truck dealerships.<br>
We do Aluminium polishing of tanks, Rims, Bullbars.<br>
We do for machine cut and polishing.<br>
We do Full interior cab and sleeper.<br>
Have a chat with one of our Mobile detailers and we can give you a estimate over the phone.<br>
We are fully mobile so we can come to you.<br>
We also do Ceramic Coatings for truck bodies.</p>
  

      <a href="truck-detailing.php">Read More</a>
    </div>
    <div class="col-md-6 del-mbl">
      <img src="images/services/07.jpg" class="img-responsive">
    </div>
  </div>


  

</div>



<div class="clearfix"></div>

<?php include('includes/footerpart.php') ?>

<script>

  (function ($) {
    'use strict';

    var form = $('.contact__form'),
    message = $('.contact__msg'),
    form_data;

    // Success function
    function done_func(response) {
      message.fadeIn()
      message.html(response);
      setTimeout(function () {
        message.fadeOut();
      }, 5000);

      form.find('input:not([type="submit"]), textarea').val('');
    }

    // fail function
    function fail_func(data) {
      message.fadeIn()
      message.html(data.responseText);
      setTimeout(function () {
        message.fadeOut(5000);
      }, 5000);
    }
    
    form.submit(function (e) {
      e.preventDefault();
      form_data = $(this).serialize();
      $.ajax({
        type: 'POST',
        url: form.attr('action'),
        data: form_data
      })
      .done(done_func)
      .fail(fail_func);
    });
  })(jQuery);
</script>

</body>
</html>